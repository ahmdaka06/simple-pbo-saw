<?php
die('null');